public enum Espezialitate {


    KORRIKALARI, TXIRRINDULARI, IGERILARI;

}

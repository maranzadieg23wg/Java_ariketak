public enum Kargu {
    piloto,
    ingeniari,
    zuzendari
}

public class F1Exception extends Exception{


    public F1Exception(String s){
        super(s);
    }
}
